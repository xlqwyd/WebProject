package data;

public class Data {
	private String flexRadioDefault;
	private int AssignmentNum;
	private String area1;
	private String namefull;
	private String phone;
	private float Temperatures;
	private String weather;
	private String surface;
	private String surface2;
	private String traffic;
	
	
	
	public String getFlexRadioDefault() {
		return flexRadioDefault;
	}
	public void setFlexRadioDefault(String flexRadioDefault) {
		this.flexRadioDefault = flexRadioDefault;
	}
	public int getAssignmentNum() {
		return AssignmentNum;
	}
	public void setAssignmentNum(int assignmentNum) {
		this.AssignmentNum = assignmentNum;
	}
	public String getArea1() {
		return area1;
	}
	public void setArea1(String area1) {
		this.area1 = area1;
	}
	public String getNamefull() {
		return namefull;
	}
	public void setNamefull(String namefull) {
		this.namefull = namefull;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public float getTemperatures() {
		return Temperatures;
	}
	public void setTemperatures(float temperatures) {
		this.Temperatures = temperatures;
	}
	public String getWeather() {
		return weather;
	}
	public void setWeather(String weather) {
		this.weather = weather;
	}
	public String getSurface() {
		return surface;
	}
	public void setSurface(String surface) {
		this.surface = surface;
	}
	public String getSurface2() {
		return surface2;
	}
	public void setSurface2(String surface2) {
		this.surface2 = surface2;
	}
	public String getTraffic() {
		return traffic;
	}
	public void setTraffic(String traffic) {
		this.traffic = traffic;
	}
	
	

	
}
