package kr.or.connect.heatmap.dto;

public class DateList {
	   private java.sql.Date date;

	   public java.sql.Date getDate() {
	      return date;
	   }

	   public void setDate(java.sql.Date date) {
	      this.date = date;
	   }
	   
	}