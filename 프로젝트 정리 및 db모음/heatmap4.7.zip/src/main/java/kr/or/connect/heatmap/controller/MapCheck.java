package kr.or.connect.heatmap.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.xml.bind.DatatypeConverter;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import kr.or.connect.heatmap.config.ApplicationConfig;

import kr.or.connect.heatmap.dao.MapCheckDao;
import kr.or.connect.heatmap.dao.MapCheckPastDao;
import kr.or.connect.heatmap.dto.HeatMapFormData;
import kr.or.connect.heatmap.dto.MapCheckData;
import kr.or.connect.heatmap.dto.pastSurveyFormData;


@Controller
public class MapCheck {
	
	//열지도 보기 페이지
   @GetMapping("/mapCheck")
   public String joina() {
      return "mapCheck";
   }
   
   // 현재 위치를 받아서 보는 페이지
   @GetMapping("/myLocation")
   public String myLocation() {
      return "myLocation";
   }

   // 검색기능
   @PostMapping("/MapC")
   public String uploadCheck(@ModelAttribute("data") MapCheckData data, ModelMap model,HttpServletRequest request) {

      return "mapCheck";
   
   }
   
   // 현재위치 받은 정보를 응답폼쪽으로 이동
   @PostMapping("/myLocation")
   public String uploadCheck(@ModelAttribute("data") MapCheckData data) {
      
      return "surveyform";
   
   }

}