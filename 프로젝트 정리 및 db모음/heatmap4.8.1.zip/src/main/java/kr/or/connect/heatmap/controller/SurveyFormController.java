package kr.or.connect.heatmap.controller;

import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.Base64;
import java.util.TimeZone;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.xml.bind.DatatypeConverter;

import org.apache.commons.io.FileUtils;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.CannedAccessControlList;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.transfer.TransferManager;
import com.amazonaws.services.s3.transfer.TransferManagerBuilder;

import kr.or.connect.heatmap.config.ApplicationConfig;
import kr.or.connect.heatmap.dao.HeatMapFormDao;
import kr.or.connect.heatmap.dto.HeatMapFormData;

@Controller
public class SurveyFormController {
	// 응답폼 작성 페이지로 이동
	@GetMapping("/surveyform")
	public String surveyform() {
		return "surveyform";
	}

	// 응답폼 제출 전 미리보기 페이지 이동
	@GetMapping("/surveyformUploadCheck")
	public String uploadcheck() {
		return "surveyformUploadCheck";
	}

	// surveyform.jsp에서 작성한 내용을 surveyformUploadCheck.jsp로 보내주고
	// 미리보기(surveyformUploadCheck.jsp)로 이동
	@PostMapping("/surveyformCheck")
	public String uploadCheck(@ModelAttribute("data") HeatMapFormData data) {
		// base64를 이용한 사진 미리보기 기능의 인코딩은 HeatMapFormData 내에 setFile1메소드에 있습니다.
		return "surveyformUploadCheck";
	}

	// 미리보기 페이지(surveyformUploadCheck.jsp)에서 제출버튼 누르면 db에 데이터와 사진 저장.(사진은 s3)
	@PostMapping("/surveyformUpload")
	public String upload(@ModelAttribute HeatMapFormData data, HttpServletRequest request,
			HttpServletResponse response) {
		HttpSession session = request.getSession();
		String id = null;
		// 세션에서 id를 가져와 id값 입력.
		if (session.getAttribute("id") != null) {
			id = (String) session.getAttribute("id");
			data.setId(id);
		}
		ApplicationContext ac = new AnnotationConfigApplicationContext(ApplicationConfig.class);
		HeatMapFormDao formdao = ac.getBean(HeatMapFormDao.class);
		// insert 메소드 사용해서 DB에 데이터 저장
		int count = formdao.insert(data);

		response.setContentType("text/html; charset=UTF-8");
		if (count == -1) {
			try {
				PrintWriter script = response.getWriter();
				script.println("<script>alert('입력된 배정번호입니다.'); history.go(-1);</script>");
				script.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		String fname = data.getDate() + "[" + data.getAssignmentNum() + "]";
		String decfile1 = data.getEncfile1();

		// base64 디코딩
		byte[] decodeBytes1 = DatatypeConverter.parseBase64Binary(decfile1);

		//여기서부터 s3 사진 코드: 키 값이랑 비밀번호 버킷 이름 삽입해야 함.
		if (count != -1) {
			AmazonS3 amazonS3 = null;
			String bucket = null;

			//s3 키값, 비밀번호 삽입 
			AWSCredentials creds = new BasicAWSCredentials("","");
			amazonS3 = AmazonS3ClientBuilder.standard().withCredentials(new AWSStaticCredentialsProvider(creds))
					.withRegion(Regions.AP_NORTHEAST_2) // region
					.withForceGlobalBucketAccessEnabled(true) // access
					.build();
			//s3 버킷 이름 삽입
			bucket = "";
			TransferManager tm = TransferManagerBuilder.standard().withS3Client(amazonS3).build();

			PutObjectRequest objrequest;
			try {
				ObjectMetadata metadata = new ObjectMetadata();
				metadata.setCacheControl("604800"); // 60*60*24*7 일주일
				metadata.setContentType("image/jpeg");
				metadata.setContentLength(decodeBytes1.length);

				objrequest = new PutObjectRequest(bucket, fname, new ByteArrayInputStream(decodeBytes1), metadata)
						.withCannedAcl(CannedAccessControlList.PublicRead);
				amazonS3.putObject(objrequest);

				/*
				 * Upload upload = tm.upload(objrequest); upload.waitForCompletion();
				 */

			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return "main";
	}
}
