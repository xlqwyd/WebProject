package kr.or.connect.heatmap.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Base64;
import java.util.TimeZone;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.xml.bind.DatatypeConverter;

import org.apache.commons.io.FileUtils;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import kr.or.connect.heatmap.config.ApplicationConfig;
import kr.or.connect.heatmap.dao.HeatMapFormDao;
import kr.or.connect.heatmap.dto.HeatMapFormData;

@Controller
public class SurveyFormController {
	// 응답폼 작성 페이지로 이동
	@GetMapping("/surveyform")
	public String surveyform() {
		return "surveyform";
	}

	// 응답폼 제출 전 미리보기 페이지 이동
	@GetMapping("/surveyformUploadCheck")
	public String uploadcheck() {
		return "surveyformUploadCheck";
	}

	// surveyform.jsp에서 작성한 내용을 surveyformUploadCheck.jsp로 보내주고
	// 미리보기(surveyformUploadCheck.jsp)로 이동
	@PostMapping("/surveyformCheck")
	public String uploadCheck(@ModelAttribute("data") HeatMapFormData data) {
		// base64를 이용한 사진 미리보기 기능의 인코딩은 HeatMapFormData 내에 setFile1메소드에 있습니다.
		return "surveyformUploadCheck";
	}

	// 미리보기 페이지(surveyformUploadCheck.jsp)에서 제출버튼 누르면 db에 데이터와 사진 저장.(사진은 s3 미구현상태)
	@PostMapping("/surveyformUpload")
	public String upload(@ModelAttribute HeatMapFormData data, HttpServletRequest request) {
		HttpSession session = request.getSession();
		String id = null;
		// 세션에서 id를 가져와 id값 입력.
		if (session.getAttribute("id") != null) {
			id = (String) session.getAttribute("id");
			data.setId(id);
		}
		ApplicationContext ac = new AnnotationConfigApplicationContext(ApplicationConfig.class);
		HeatMapFormDao formdao = ac.getBean(HeatMapFormDao.class);
		// insert 메소드 사용해서 DB에 데이터 저장
		int count = formdao.insert(data);

		// 이 아래는 기존 사진 저장에 사용되던 코드입니다(s3 적용 x).

		// 사진파일 저장시 날짜를 이용한 폴더 생성에 사용.
		TimeZone.setDefault(TimeZone.getTimeZone("Asia/Seoul"));// 서버 시간설정 관계없이 한국시간이 객체에 기록
		java.util.Date utilDate = new java.util.Date();// 실제 적용되는지 확인 불가. 확인 부탁드립니다.
		java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());

		String decfile1 = data.getEncfile1();

		File file1 = new File(data.getFilename1());
		// base64 디코딩
		byte[] decodeBytes1 = DatatypeConverter.parseBase64Binary(decfile1);

		int assignmentNum = data.getAssignmentNum();
		// 사진 저장 경로. 바꿔줘야함.현재 AWS하기전 임시로 로컬이기때문에 자신의 컴퓨터에 저장될곳 경로설정
		String path = "C:/ProjectPicture/" + sqlDate + "/";
		// String path="C:\\Users\\박재현\\eclipse-workspace\\heatmap2.6\\src\\main\\webapp\\resources\\img\\Picture/"+sqlDate+"/";
		//사진 저장 경로. 자신의 컴퓨터에 맞게 바꿔야함.
		// String path="C:/Users/tongsu/Pictures/"+sqlDate+"/";
		File dir = new File(path);
		if (!dir.exists()) {
			dir.mkdirs();
		}

		path = path + assignmentNum + "/";
		File dir2 = new File(path);
		if (!dir2.exists()) {
			dir2.mkdirs();
		}

		try (

				OutputStream outputStream1 = new BufferedOutputStream(new FileOutputStream(path + file1));

		) {

			outputStream1.write(decodeBytes1);
		} catch (Exception ex) {
			throw new RuntimeException("file Save Error");
		}

		return "main";
	}
}
