-- MySQL dump 10.13  Distrib 8.0.23, for Win64 (x86_64)
--
-- Host: localhost    Database: testing1
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `data`
--

DROP TABLE IF EXISTS `data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `data` (
  `참가자유형` varchar(10) NOT NULL,
  `측정날짜` date NOT NULL,
  `배정번호` int NOT NULL,
  `측정지` varchar(100) NOT NULL,
  `측정자성명` varchar(10) NOT NULL,
  `측정자연락처` varchar(11) NOT NULL,
  `기온` float(3,1) NOT NULL,
  `기상상태` varchar(20) NOT NULL,
  `지면상태1` varchar(20) NOT NULL,
  `지면상태2` varchar(30) NOT NULL,
  `교통사항` varchar(20) NOT NULL,
  `측정시간` time NOT NULL,
  `fileName` varchar(200) DEFAULT NULL,
  `fileName2` varchar(200) DEFAULT NULL,
  `id` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`측정날짜`,`배정번호`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `data`
--

LOCK TABLES `data` WRITE;
/*!40000 ALTER TABLE `data` DISABLE KEYS */;
INSERT INTO `data` VALUES ('기존','0000-00-00',1,'어딘가','박재현','01000000000',10.0,'맑음','콘크리트','비나 물에 젖음','한산','00:00:00',NULL,NULL,NULL),('기존','0000-00-00',111,'천안시','이이이','01011111111',11.0,'맑음','콘크리트','비나 물에 젖음','한산','00:00:00',NULL,NULL,NULL),('기존','0000-00-00',123,'천안시','이이잉','01011111111',20.1,'구름많고 흐림','콘크리트','비나 물에 젖음','한산','00:00:00',NULL,NULL,NULL),('신규','2021-04-01',134,'처난시','천안상','01011233123',1.0,'맑음','아스팔트','해당없음','보통','22:22:01',NULL,NULL,NULL),('기존','2021-04-02',1,'천안시','천안사','01055554444',6.0,'맑음','우레틴 및 고무','해당없음','보통','17:03:58',NULL,NULL,NULL),('신규','2021-04-02',12,'fd','asdf','33344442222',4.0,'구름많고 흐림','아스팔트','비나 물에 젖음','한산','14:42:22',NULL,NULL,NULL),('기존','2021-04-02',18,'df','fds','01012344567',32.0,'약한비','우레틴 및 고무','해당없음','혼잡','01:23:22',NULL,NULL,NULL),('기존','2021-04-02',21,'re','asdf','01022225555',43.2,'구름많고 흐림','흙/모래','비나 물에 젖음','한산','01:12:58',NULL,NULL,NULL),('기존','2021-04-02',23,'fr','df','01055554444',34.0,'구름많고 흐림','콘크리트','해당없음','보통','17:18:30',NULL,NULL,NULL),('기존','2021-04-02',30,'천안시','ㄱㄱ','01055554444',34.0,'약한비','아스팔트','비나 물에 젖음','한산','19:35:39',NULL,NULL,NULL),('신규','2021-04-02',31,'ㅇㅇ','ㅇㅇㅇ','11111111111',21.0,'약한비','콘크리트','비나 물에 젖음','혼잡','00:15:43',NULL,NULL,NULL),('기존','2021-04-02',32,'천안시','천안사','12344448888',35.0,'약한비','콘크리트','비나 물에 젖음','한산','16:57:25',NULL,NULL,NULL),('신규','2021-04-02',41,'ff','ff','00333335555',43.0,'강한비','흙/모래','비나 물에 젖음','혼잡','13:54:34',NULL,NULL,NULL),('신규','2021-04-02',43,'천안','애애애','00000000000',21.0,'구름많고 흐림','잔디','비나 물에 젖음','혼잡','00:04:57',NULL,NULL,NULL),('기존','2021-04-02',45,'cdf','df','12345678978',1.0,'구름많고 흐림','콘크리트','해당없음','혼잡','14:21:42',NULL,NULL,NULL),('기존','2021-04-02',53,'ccc','ccc','02022223333',3.0,'구름많고 흐림','잔디','해당없음','도로없음','00:20:08',NULL,NULL,NULL),('기존','2021-04-02',54,'ffd','fsda','03002225555',43.0,'약한비','잔디','비나 물에 젖음','혼잡','00:56:32',NULL,NULL,NULL),('기존','2021-04-02',75,'ㄱㄱ','천안사','55555555555',6.0,'맑음','콘크리트','비나 물에 젖음','한산','17:02:24',NULL,NULL,NULL),('기존','2021-04-02',86,'ddd','asd','02033335555',23.0,'비가 오다 그친 상태','우레틴 및 고무','비나 물에 젖음','보통','00:46:28',NULL,NULL,NULL),('기존','2021-04-02',152,'천안시','천안사','01055554444',34.0,'맑음','아스팔트','비나 물에 젖음','혼잡','23:53:37',NULL,NULL,NULL),('기존','2021-04-02',176,'천안시','천안사','12344448888',4.0,'구름많고 흐림','흙/모래','비나 물에 젖음','보통','17:06:56',NULL,NULL,NULL),('기존','2021-04-02',280,'df','fd','01055554444',3.0,'맑음','콘크리트','해당없음','보통','19:28:25',NULL,NULL,NULL),('신규','2021-04-02',281,'천안시','ㄹㅇ','01055554444',43.0,'구름많고 흐림','아스팔트','비나 물에 젖음','혼잡','19:33:42',NULL,NULL,NULL),('신규','2021-04-06',12,'천안시','천안사','01055554444',23.4,'맑음','콘크리트','비나 물에 젖음','한산','22:48:37','gdasdf.PNG','ㅁㄴㅇㄹ..PNG',NULL),('기존','2021-04-06',13,'천안시','천안사','12344448888',32.4,'맑음','콘크리트','해당없음','보통','22:50:32',NULL,NULL,NULL),('기존','2021-04-25',13,'천안시','천안사','01055554444',43.0,'맑음','흙/모래','해당없음','보통','14:16:23','6.3.3.PNG','6.3.3.PNG',NULL);
/*!40000 ALTER TABLE `data` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-05-19 17:39:24
