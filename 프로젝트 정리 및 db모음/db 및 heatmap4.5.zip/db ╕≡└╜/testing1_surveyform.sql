-- MySQL dump 10.13  Distrib 8.0.23, for Win64 (x86_64)
--
-- Host: localhost    Database: testing1
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `surveyform`
--

DROP TABLE IF EXISTS `surveyform`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `surveyform` (
  `date` date NOT NULL,
  `assignment_num` int NOT NULL,
  `id` varchar(20) DEFAULT NULL,
  `area1` varchar(100) DEFAULT NULL,
  `namefull` varchar(10) DEFAULT NULL,
  `temperatures` float(3,1) DEFAULT NULL,
  `weather` varchar(20) DEFAULT NULL,
  `time` time DEFAULT NULL,
  `filename1` varchar(200) DEFAULT NULL,
  `latitude` decimal(20,16) DEFAULT NULL,
  `longitude` decimal(20,16) DEFAULT NULL,
  PRIMARY KEY (`date`,`assignment_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `surveyform`
--

LOCK TABLES `surveyform` WRITE;
/*!40000 ALTER TABLE `surveyform` DISABLE KEYS */;
INSERT INTO `surveyform` VALUES ('2021-05-13',12,'fff','천안시','이이이',23.0,'sunny','18:34:09','온도꼐.jpeg',36.8110800000000000,127.2226000000000000),('2021-05-13',23,'asdf','천안시','천안사',2.0,'sunny','18:21:19','온도꼐.jpeg',36.8150861932929560,127.1136094000749000),('2021-05-13',43,'fff','천안시','천안사',2.0,'sunny','19:28:11','온도꼐.jpeg',36.8110700000000000,127.1125000000000000),('2021-05-14',23,'asdf','천안시','천안사',3.0,'rain','13:21:27','회원가입 성공시.JPG',36.8150861932929560,127.1136094000749000),('2021-05-14',43,'asdf','천안시','이이이',1.0,'blur','13:15:20','회원가입 성공시.JPG',36.8110700000000000,127.1125000000000000),('2021-05-16',5,'fff','천안시','이리히',22.0,'sunny','21:55:29','20210507_130929.jpg',36.8810800000000000,127.1126000000000000),('2021-05-17',23,'fff','ㄱㄱ','천안사',32.0,'sunny','22:30:17','6.3.3.PNG',36.8500000000000000,127.1500000000000000),('2021-05-18',1,'admin','천안시','홍길동',14.0,'sunny','22:34:48','sql 회원가입 저장 모습.JPG',36.8230000000000000,127.1150000000000000),('2021-05-19',125,'fff','천안시','홍길동',34.0,'sunny','15:19:23','sql 회원가입 저장 모습.JPG',37.2042686000000000,126.8033590000000000),('2022-01-01',13,'fff','천안시','천안사',5.0,'sunny','20:08:01','온도계.jpeg',36.8123000000000000,127.2224000000000000);
/*!40000 ALTER TABLE `surveyform` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-05-19 17:39:24
