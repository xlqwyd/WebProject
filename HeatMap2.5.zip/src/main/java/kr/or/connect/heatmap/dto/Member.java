package kr.or.connect.heatmap.dto;

public class Member {
	
	private String id;
	private String password;
	private String password2;
	private String email;
	
	public String getPassword2() {
		return password2;
	}
	public void setPassword2(String password2) {
		this.password2 = password2;
	}
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Override
	public String toString() {
		return "Member [id=" + id + ", password=" + password + ", password2=" + password2 + ", email=" + email + "]";
	}
	

	
	
	
}
