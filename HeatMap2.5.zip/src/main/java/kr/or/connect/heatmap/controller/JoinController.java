package kr.or.connect.heatmap.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.multipart.MultipartFile;

import kr.or.connect.heatmap.config.ApplicationConfig;

import kr.or.connect.heatmap.dao.MemberDao;

import kr.or.connect.heatmap.dto.Member;


@Controller
public class JoinController {

	
	@GetMapping("/join")
	public String joina() {
		return "join";
	}
	
	
	
	@PostMapping("/JoinControl")
	public String upload(@ModelAttribute Member member, HttpServletResponse response, HttpServletRequest request) throws Exception{
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter script = response.getWriter();
		
		if(member.getId() == null || member.getPassword() == null || member.getEmail() == null ||  member.getPassword2() == null) {
			
			//PrintWriter script = response.getWriter();
			script.println("<script>alert('미입력 정보있음.'); history.go(-1);</script>");
			script.close();
		}
		else if((member.getPassword().equals(member.getPassword2())) != true){ //비밀번호 불일치
			//PrintWriter script = response.getWriter();
			/*script.println("<script>");
			script.println("alert('비밀번호 불일치.')");  
			script.println("history.back()");
			script.println("</script>");
			*/
			//response.setCharacterEncoding("UTF-8");
			//response.setContentType("text/html; charset=UTF-8");

			script.println("<script>alert('비밀번호 불일치.'); history.go(-1);</script>");
			script.close();

			
		}
		else {   // 페이지에서 받아온 정보들은 insert전 확인 작업을 통해 확인이 되면 그때 dao객체 관련을 생성하여 넣어야함 (아니면 넣고 확인하는 작업이라 의미X)
			ApplicationContext ac = new AnnotationConfigApplicationContext(ApplicationConfig.class);
			MemberDao formdao2 = ac.getBean(MemberDao.class);
			formdao2.insert2(member);   //insert를 통해 sql에 추가 부분
			
			HttpSession session = request.getSession();

			
			session.setAttribute("id", member.getId());
			script.println("<script>alert('회원가입 완료.'); location.href = '/heatmap/';</script>");
			script.close();
		}
		
		
		
		
        
		return "main"; //else를 통해 마무리시 메인 화면으로
	}
	
}
