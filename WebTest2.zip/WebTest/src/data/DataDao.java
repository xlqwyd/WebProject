package data;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DataDao {
	
	private Connection conn;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	public DataDao() {
		try {
			String dbURL = "jdbc:mysql://localhost:3306/testing1";
					String dbID = "root";
			String dbPassword = "971008";
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(dbURL, dbID, dbPassword);
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public int join(Data data, String id) {   //응답폼
		String SQL = "INSERT INTO data VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		
		java.util.Date utilDate = new java.util.Date();
		java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
		java.sql.Time sqlTime = new java.sql.Time(utilDate.getTime());
		
		try {
			
			pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1, data.getFlexRadioDefault());
			pstmt.setDate(2, sqlDate);
			pstmt.setInt(3, data.getAssignmentNum());
			pstmt.setString(4, data.getArea1());
			pstmt.setString(5, data.getNamefull());
			pstmt.setString(6, data.getPhone());
			pstmt.setFloat(7, data.getTemperatures());
			pstmt.setString(8, data.getWeather());
			pstmt.setString(9, data.getSurface());
			pstmt.setString(10, data.getSurface2());
			pstmt.setString(11, data.getTraffic());
			pstmt.setTime(12, sqlTime);
			pstmt.setString(13, data.getFileName1());
			pstmt.setString(14, data.getFileName2());
			pstmt.setString(15, id);
			pstmt.executeUpdate();
			return 0;
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			
			if (pstmt != null) {
				try {
					pstmt.close();   //메모리해제
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();  //메모리 해제2
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
		return -1; //db오류
		
	}
	
	public int realLogin(String id, String password) {  //로그인시 
		String SQL = "SELECT password FROM MEMBER WHERE id = ?";
		try {
			pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				if(rs.getString(1).equals(password)) {
					return 1; //해당 아이디가 비밀번호까지 일치시
				}
				else
					return 0; //비밀번호 불일치시
			}
			return -1; //아이디가 없을시 -1반환
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		return -2; //데이터 베이스 오류
	}

	
	
	public int realJoin(Member member) {  //회원가입시
		String SQL = "INSERT INTO member VALUES (?, ?, ?, ?)";
		
		
		
		try {
			
			pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1, member.getId());
			
			pstmt.setString(2, member.getPassword());
			pstmt.setString(3, member.getEmail());
			pstmt.setString(4, member.getVms_id());
			
			pstmt.executeUpdate();
			return 0;
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			
			if (pstmt != null) {
				try {
					pstmt.close();   //메모리해제
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();  //메모리 해제2
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
		return -1; //db오류
		
	}
	
	
	
	
	
	
	
}

