package kr.or.connect.heatmap.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class RealLoginController {
	
	@GetMapping("/RealLogin")
	public String reallogin() {
		return "RealLogin";
	}
	
	@RequestMapping("/logout")
    public ModelAndView logout(HttpSession session, HttpServletResponse response) throws Exception {
		//PrintWriter script = response.getWriter();
        session.invalidate();  //세션 초기화
       /* response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");

		script.println("<script>alert('logout complete.');</script>");
		script.close();
		*/
        ModelAndView mv = new ModelAndView("redirect:/");   //돌아가기
        return mv;
        
    }


	


	
	
	
	
	
}
