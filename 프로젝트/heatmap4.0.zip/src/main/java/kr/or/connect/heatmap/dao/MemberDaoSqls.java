package kr.or.connect.heatmap.dao;

public class MemberDaoSqls {  //미사용 중
	public static final String SELECT_ALL = "SELECT id, password FROM member order by id";

}
