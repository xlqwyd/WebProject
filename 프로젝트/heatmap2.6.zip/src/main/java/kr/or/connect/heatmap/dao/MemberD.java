package kr.or.connect.heatmap.dao;

import kr.or.connect.heatmap.dto.Member;

public interface MemberD {

	void register(Member member) throws Exception;
}
